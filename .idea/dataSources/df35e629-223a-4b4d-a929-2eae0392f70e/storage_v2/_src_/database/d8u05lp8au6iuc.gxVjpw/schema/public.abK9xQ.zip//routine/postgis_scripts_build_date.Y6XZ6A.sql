create function postgis_scripts_build_date() returns text
    immutable
    language sql
as
$$
SELECT '2022-02-13 06:57:40'::text AS version
$$;

comment on function postgis_scripts_build_date() is 'Returns build date of the PostGIS scripts.';

alter function postgis_scripts_build_date() owner to postgres;

